﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Proyecto_AdEMP
{
    public partial class EstadisticasSalario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    
    protected string obtenerDatos(){

            SqlConnection conexionSQL = new SqlConnection("Data Source=DESKTOP-9UFSBKV\\SQLEXPRESS;Initial Catalog=AdEMP;Integrated Security=True");

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select nombre_categoria, salario from categoria";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = conexionSQL;
            conexionSQL.Open();
            DataTable Datos = new DataTable();
            Datos.Load(cmd.ExecuteReader());
            conexionSQL.Close();


        string strDatos;

        strDatos = "[['name','Horas'],";

        foreach(DataRow dr in Datos.Rows)
        {
            strDatos = strDatos + "[";
            strDatos = strDatos + "'"+dr[0]+"'"+","+dr[1];
            strDatos = strDatos + "],";
        }

        strDatos = strDatos + "]";
        return strDatos;
    }
    }

}